<?php
/**
 * PLANTILLA de config/getnet.config.php (copiala con ese nombre y completala).
 * El archivo real NO se sube a GitHub (agregalo al .gitignore, igual que
 * config_mail.php) y en Hostinger se crea a mano.
 *
 * Credenciales: portal de comercios de Getnet → Productos digitales → Integraciones.
 * Se generan por separado para preproducción (sandbox) y producción.
 */
return [
    // Solo aplica en el servidor: en tu PC (localhost) siempre se usa 'sandbox'.
    'entorno' => 'sandbox', // 'sandbox' | 'produccion'

    'sandbox' => [
        'client_id'     => 'cid_bb340948-53a7-478c-a939-991b4f8d06d9',
        'client_secret' => 'ee5e5da0-1507-427c-955f-0176fa7431ee',
        'auth_url'      => 'https://api.pre.globalgetnet.com/authentication/oauth2/access_token', // TODO(doc): confirmar
        'api_base'      => 'https://TODO-sandbox.globalgetnet.com.ar', // TODO(doc): URL de preproducción
    ],
    'produccion' => [
        'client_id'     => 'CLIENT_ID_PRODUCCION',
        'client_secret' => 'CLIENT_SECRET_PRODUCCION',
        'auth_url'      => 'https://auth.geopagos.com/oauth/token', // TODO(doc): confirmar
        'api_base'      => 'https://api.globalgetnet.com.ar',       // TODO(doc): confirmar
    ],

    'return_url'  => 'https://vivemundoverde.com/pago_resultado.html',
    'webhook_url' => 'https://vivemundoverde.com/mundo_verde_backend/api/pagos/webhook',

    // Texto largo y aleatorio (ej.: bin2hex(random_bytes(24))). Viaja como ?k=... en la URL del webhook.
    'webhook_token' => 'CAMBIAR_POR_UN_TOKEN_LARGO_Y_ALEATORIO',
];
