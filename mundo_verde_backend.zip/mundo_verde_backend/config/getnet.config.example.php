<?php
/**
 * PLANTILLA de config/getnet.config.php (copiala con ese nombre y completala).
 * El archivo real NO se sube a GitHub (agregalo al .gitignore, igual que config_mail.php) y en Hostinger
 * se crea a mano. ESTA plantilla no debe llevar credenciales reales: si ya pegaste las tuyas acá, regeneralas.
 *
 * Credenciales: Portal de Comercios de Getnet → Productos digitales → Integraciones → Generar credenciales
 * (se generan por separado para preproducción/sandbox y producción; el secret se muestra UNA sola vez).
 *
 * Documentación: https://docs.globalgetnet.com → Payments → Web Checkout
 */
return [
    // Solo aplica en el servidor: en tu PC (localhost) siempre se usa 'sandbox'.
    'entorno' => 'sandbox', // 'sandbox' | 'produccion'

    'sandbox' => [
        'client_id'     => 'cid_bb340948-53a7-478c-a939-991b4f8d06d9',
        'client_secret' => 'ee5e5da0-1507-427c-955f-0176fa7431ee',
        'auth_url'      => 'https://api.pre.globalgetnet.com/authentication/oauth2/access_token',
        'api_base'      => 'https://api.pre.globalgetnet.com',
    ],
    'produccion' => [
        'client_id'     => 'CLIENT_ID_PRODUCCION',
        'client_secret' => 'CLIENT_SECRET_PRODUCCION',
        'auth_url'      => 'https://api.globalgetnet.com/authentication/oauth2/access_token',
        'api_base'      => 'https://api.globalgetnet.com',
    ],

    // Contrato de la API (Web Checkout, Argentina). Los valores por defecto ya son los de la documentación;
    // solo hace falta tocar esto si probar_pago_getnet.php muestra algo distinto.
    'api' => [
        'crear_pago_path'     => '/payment-intent', // prefijo exacto: confirmar con probar_pago_getnet.php (puede ser p. ej. /digital-checkout/v1/payment-intent)
        'consultar_pago_path' => '',                // la doc pública no muestra consulta de estado. Si Getnet te da una: '/ruta/{id}'
        'expira'              => '1h',              // el link de pago vence (mín. 15m). Dejar igual a la limpieza de pedidos (60 min)
    ],

    // Dónde vuelve el cliente (se manda en cada pago; también cargalas en el Portal: son obligatorias ahí).
    'return_url'  => 'https://vivemundoverde.com/pago_resultado.html',

    // ── Aviso de pago (webhook) ──────────────────────────────────────────────
    // La URL se carga EN EL PORTAL DE COMERCIOS (Web Checkout → paso 4), no se manda en cada pago:
    //   https://vivemundoverde.com/mundo_verde_backend/api/pagos/webhook?k=EL_TOKEN_DE_ABAJO
    // En ese mismo paso el Portal pide un usuario y una contraseña: Getnet los manda con cada aviso
    // (Authorization: Basic) y acá se validan. Ponelos IGUALES a lo que cargues en el Portal.
    'webhook_usuario'  => 'USUARIO_DEL_WEBHOOK',
    'webhook_password' => 'CLAVE_LARGA_Y_ALEATORIA',
    // Capa extra: texto largo y aleatorio (ej.: bin2hex(random_bytes(24))). Viaja como ?k=... en la URL.
    'webhook_token'    => 'A25sd6ej7m9dfe3mxzops9q2j4l1a8b0sSw4DASDSSsdnc698023dff55d66f8g87dssd',
];
