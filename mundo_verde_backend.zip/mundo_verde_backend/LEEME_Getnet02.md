# Pago con tarjeta (Getnet Web Checkout) — qué hay en este zip

Copiá cada archivo a la misma ruta de tu proyecto. **No incluye tus claves.**

## 1. Tu `config/getnet.config.php` (el real, en tu PC y en Hostinger)
Basate en `config/getnet.config.example.php`. Lo que hay que corregir respecto de lo que tenías:
- `auth_url` → `https://api.pre.globalgetnet.com/authentication/oauth2/access_token` (sandbox) y `https://api.globalgetnet.com/authentication/oauth2/access_token` (producción). **`auth.geopagos.com` no es.**
- `api_base` → `https://api.pre.globalgetnet.com` (sandbox) y `https://api.globalgetnet.com` (producción).
- Agregá `webhook_usuario` y `webhook_password` (los mismos que cargues en el Portal, ver punto 2).
- Borrá `webhook_url` (ya no se usa: la URL del aviso se carga en el Portal).
- El bloque `'api'` ya no necesita `COMPLETAR`: los valores por defecto son los de la documentación. Solo `crear_pago_path` puede requerir ajuste (punto 3).
- **Regenerá las credenciales sandbox y el `webhook_token`**: estaban pegados en el archivo `*_example.php` que me mandaste y en el zip anterior. Esa plantilla no debe llevar datos reales (la que va acá viene con placeholders).

## 2. Portal de Comercios de Getnet (Web Checkout → configuración, 4 pasos)
1. Medios de pago y cuotas (crédito, débito, QR; planes de cuotas del emisor y Cuota Simple / Plan Ahora).
2. Personalización (opcional).
3. URLs de retorno: éxito y error → `https://vivemundoverde.com/pago_resultado.html` (las dos; son obligatorias ahí).
4. Webhook: URL `https://vivemundoverde.com/mundo_verde_backend/api/pagos/webhook?k=TU_WEBHOOK_TOKEN` + usuario y contraseña
   (Getnet los manda como `Authorization: Basic`). Deben ser iguales a `webhook_usuario` / `webhook_password` de tu config.
   Getnet reintenta hasta 72 h si no recibe un 200.

## 3. Confirmar el path (un solo comando)
`php api/probar_pago_getnet.php` — autentica, crea un pago de $100 en sandbox y prueba el path `/payment-intent` y variantes con prefijo.
Te dice qué poner en `crear_pago_path`, qué campos devuelve y, si el cuerpo falta algún dato (p. ej. documento del cliente), el mensaje de Getnet.
**Borralo antes de subir a Hostinger** (igual que `api/probar_getnet.php`, que ya no hace falta).

## 4. Cambios en el código
- `api/getnet.php`: contrato real de Web Checkout (payment intent, centavos, `order_id`, `redirect_url`, vencimiento 1 h).
- `api/controllers/pagos.php`: aviso autenticado con Basic + `?k=`; verifica referencia, monto y moneda; acepta `Authorized`/`Approved` (tarjeta/QR) y `Denied`;
  si Getnet no ofrece consulta de estado, se apoya en el aviso autenticado.
- `api/.htaccess`: pasa el encabezado `Authorization` a PHP (algunos hostings lo descartan).
- `tests/`: 101 pruebas (`python3 tests/run_tests.py`) contra un Getnet simulado con el formato de la documentación.
  Validan la lógica de Mundo Verde, no el servidor real de Getnet.
- Se mantienen los arreglos anteriores (Código Verde, mail de invitados, número de pedido único) y la limpieza de Mercado Pago/MODO/cuotas.

## No subas a producción
`api/probar_pago_getnet.php`, `api/probar_getnet.php` y la carpeta `tests/`.
